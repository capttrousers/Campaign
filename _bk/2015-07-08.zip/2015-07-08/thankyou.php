<?php include 'header.php'; ?>
    <section>
        <h2>Campaign Home</h2>
        <?php echo $thankyou_message; ?>
    </section>
<?php include 'footer.php'; ?>