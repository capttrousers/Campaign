   
    <footer>
        <h3><a href="index.php?action=home">Campaign HQ</a></h3>
        <br>
        <h4>This Campaign, LLC -- Copyright 2015</h4>
    </footer>
</body>
</html>