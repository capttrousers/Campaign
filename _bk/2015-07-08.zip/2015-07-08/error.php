<?php include 'header.php'; ?>
    <section>
        <br>
        <h2>Error Page</h2>
        <?php echo $error_message; ?>
    </section>
<?php include 'footer.php'; ?>