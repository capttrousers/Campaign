<?php include 'header.php'; ?>
    <section>
        <h2>Admin Page</h2>
        <a href="./index.php?action=list-voters">List Voters</a><br>
        <a href="./index.php?action=list-staff">List Staff</a><br>
        <a href="./index.php?action=list-donations">List Donations</a><br>
        <a href="./index.php?action=add-voter-form">Add Voter</a><br>
        <a href="./index.php?action=add-staff-form">Add Staff</a><br>
    </section>
<?php include 'footer.php'; ?>